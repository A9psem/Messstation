package weathermodel.model;

public interface Converter
{
    
    default public String convertToRCF3339Date(int year,int month,int day,int hour,int minute,int seconds) {
        String cDate = "";
        String Smonth = addZeroDate(month);
        String Sday = addZeroDate(day);
        String Shour = addZeroDate(hour);
        String Sminutes = addZeroDate(minute);
        String Sseconds = addZeroDate(seconds);
        cDate = year+"-"+Smonth+"-"+Sday+"T"+Shour+":"+Sminutes+":"+Sseconds+"Z";
        return cDate;
    }
    //Creating a Bounding Box with a radius of the Distance in kilometers. Created from a Lon-Lat Double ValuePair.
    default public String makeBBox(double[] coordinates,double distance) throws Exception {
        String out = "";
        double[] bbox = new double[4];
        if (coordinates.length==2) {
            bbox[0] = coordinates[0]-distance/71.44;
            bbox[1] = coordinates[1]-distance/111.3;
            bbox[2] = coordinates[0]+distance/71.44;
            bbox[3] = coordinates[1]+distance/111.3;
            out = bbox[0]+",%20"+bbox[1]+",%20"+bbox[2]+",%20"+bbox[3];
        } else {
            throw new Exception("Please provide two Double Values for making a BBox");
        }
        return out;
    }
    //Converts a RCF3339-Date String from MESZ-Timezone to UTC-Timezone with an additional Offset-String HH:MM:SS.
    default public String shiftMESZtoUTC(String timeString,String addOffset) {
        String out = "";
        String[] sp1 = timeString.split("T");
        String[] sp2 = sp1[1].split(":");
        String[] sp3 = addOffset.split(":");
        String[] sp4 = sp1[0].split("-");
        int h1 = Integer.valueOf(sp2[0]);
        int m1 = Integer.valueOf(sp2[1]);
        int s1 = Integer.valueOf(sp2[2].replace("Z",""));
        int h2 = Integer.valueOf(sp3[0]);
        int m2 = Integer.valueOf(sp3[1]);
        int s2 = Integer.valueOf(sp3[2]);
        int ye = Integer.valueOf(sp4[0]);
        int mo = Integer.valueOf(sp4[1]);
        int da = Integer.valueOf(sp4[2]);
        int hf = h1-2+h2;
        int mf = m1+m2;
        int sf = s1+s2;
        while (sf<0) {
            sf = sf+60;
            mf--;
        } while (sf>=60) {
            sf = sf-60;
            mf++;
        } while (mf<0) {
            mf = mf+60;
            hf--;
        } while (mf>=60) {
            mf = mf-60;
            hf++;
        } while (hf<0) {
            hf = hf+24;
            da--;
        } while (hf>=24) {
            hf = hf-24;
            da++;
        }
        //This misses the month and year-switch part. This is still to add or the program will be inactive for two hours (or more) at the beginning of every year/month.
        String Smonth = addZeroDate(mo);
        String Sday = addZeroDate(da);
        String Shour = addZeroDate(hf);
        String Sminutes = addZeroDate(mf);
        String Sseconds = addZeroDate(sf);
        out = ye+"-"+Smonth+"-"+Sday+"T"+Shour+":"+Sminutes+":"+Sseconds+"Z";
        return out;
    }
    //Gets the unit of a specific phenomenon
    default public String getUnit(String phenomenon) {
        switch (phenomenon) {
            case "Temperatur": return "°C";
            case "Luftdruck": return "Pa";
            case "PM2.5": return "µg/m^3";
            case "PM10": return "µg/m^3";
            case "rel.%20Luftfeuchte": return "%";
            default: return "";
        }
    }
    
    default String addZeroDate(int input) {
        String out = "";
        if (input<10) out = "0"+input;
        else out = ""+input;
        return out;
    }
}

