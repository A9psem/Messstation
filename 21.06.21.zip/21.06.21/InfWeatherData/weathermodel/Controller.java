package weathermodel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import java.util.ArrayList;
import javafx.scene.text.Font;
import javafx.event.EventHandler;

import weathermodel.model.*;
import weathermodel.assets.*;

public class Controller implements Converter {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button buttonStart;

    @FXML
    private TextField txtLat;

    @FXML
    private TextField txtLon;

    @FXML
    private Slider sliderRadius;

    @FXML
    private VBox VBoxFS2_5;

    @FXML
    private VBox VBoxTemp;

    @FXML
    private VBox VBoxLuft;

    @FXML
    private VBox VBoxFS10;

    @FXML
    private VBox VBoxDruck;
    
    private ModelMain model;
    private ArrayList<String> requests;

    @FXML
    void init(ActionEvent event) {
        try {
            requests = new ArrayList<String>();
            double lat = Double.valueOf(txtLat.getText());
            double lon = Double.valueOf(txtLon.getText());
            double[] coords = {lon,lat};
            requests.add("LocalTemp");
            requests.add("LocalPM2.5");
            requests.add("LocalPres");
            requests.add("LocalPM10");
            requests.add("LocalHumd");
            double dis = sliderRadius.getValue();
            System.out.println("Distance: "+dis);
            model = new ModelMain(coords,dis,this);
        } catch (Exception e) {
            System.out.println("Error while initializing the model. Please check your coordinate-inserts.");
            return;
        }
    }
    
    public void requestTaken(Series insert) {
        String name = insert.getGenerator().getName();
        String res = "";
        for (String s : requests) {
            if (name.equals(s)) res = s;
        }
        if (!res.equals("")) {
            requests.remove(res);
            DataRequest r = insert.getGenerator();
            VBox box = r.getBox();
            ArrayList<Measurement> in = insert.getMeasurements();
            float av = 0;
            int count = 0;
            for (Measurement m : in) {
                av = av + m.getValue();
                count++;
            }
            av = av/count;
            addAverage(av,r.getPhenomenon(),box);
            count = 0;
            for (Measurement m : in) {
                if (count<5) {
                    addMeasurementToVBox(m,r.getPhenomenon(),box);
                    count++;
                }
            }
            addExtendButton(insert,box);
        } else return;
    }
    public void additionalInfo(Series insert) {
        DataRequest r = insert.getGenerator();
        VBox box = r.getBox();
        box.getChildren().clear();
        ArrayList<Measurement> in = insert.getMeasurements();
        float av = 0;
        int count = 0;
        for (Measurement m : in) {
            av = av + m.getValue();
            count++;
        }
        av = av/count;
        addAverage(av,r.getPhenomenon(),box);
        for (Measurement m : in) {
            addMeasurementToVBox(m,r.getPhenomenon(),box);
        }
    }
    
    public VBox[] getStartBoxes() {
        VBox[] ar = {VBoxTemp,VBoxFS2_5,VBoxDruck,VBoxFS10,VBoxLuft};
        return ar;
    }
    
    private void addMeasurementToVBox(Measurement m,String phenomenon,VBox vbox) {
        float val = m.getValue();
        String rcf = m.getTimeStamp();
        double lat = m.getLat();
        double lon = m.getLon();
        DateTime dt = new DateTime(rcf);
        HBox hbox = new HBox();
        TextField t1 = new TextField(((Float)val).toString()+getUnit(phenomenon));
        TextField t2 = new TextField(dt.getDateTimeFormatted());
        TextField t3 = new TextField("At Location: "+lat+", "+lon);
        t1.setPrefSize(125,25);
        t2.setPrefSize(225,25);
        t3.setPrefSize(250,25);
        t1.setEditable(false);
        t2.setEditable(false);
        t3.setEditable(false);
        hbox.getChildren().add(t1);
        hbox.getChildren().add(t2);
        hbox.getChildren().add(t3);
        vbox.getChildren().add(hbox);
    }
    private void addAverage(float average,String phenomenon,VBox vbox) {
        HBox hbox = new HBox();
        TextField t1 = new TextField("On Average: "+((Float)average).toString()+getUnit(phenomenon));
        t1.setPrefSize(600,40);
        t1.setEditable(false);
        t1.setFont(new Font(24));
        hbox.getChildren().add(t1);
        vbox.getChildren().add(hbox);
    }
    private void addExtendButton(Series insert,VBox vbox) {
        StorageButton b = new StorageButton("Show All",insert);
        b.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                additionalInfo((Series)b.getObject());
            }
        });
        vbox.getChildren().add(b);
    }

    @FXML
    void initialize() {
        assert buttonStart != null : "fx:id=\"buttonStart\" was not injected: check your FXML file 'view.fxml'.";
        assert txtLat != null : "fx:id=\"txtBreitengrad\" was not injected: check your FXML file 'view.fxml'.";
        assert txtLon != null : "fx:id=\"txtLaengengrad\" was not injected: check your FXML file 'view.fxml'.";
        assert sliderRadius != null : "fx:id=\"sliderRadius\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxFS2_5 != null : "fx:id=\"VBoxFS2_5\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxTemp != null : "fx:id=\"VBoxTemp\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxLuft != null : "fx:id=\"VBoxLuft\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxFS10 != null : "fx:id=\"VBoxFS10\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxDruck != null : "fx:id=\"VBoxDruck\" was not injected: check your FXML file 'view.fxml'.";

    }
}


