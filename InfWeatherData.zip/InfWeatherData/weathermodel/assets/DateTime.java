package weathermodel.assets;

import java.util.ArrayList;
public class DateTime
{
    private int yr;
    private int mo;
    private int da;
    private int hr;
    private int mi;
    private int sc;
    //Speichert Zeit und Datum in einem brauchbaren Format
    public DateTime(int year,int month,int day,int hour,int min,int sec)
    {
        yr = year;
        mo = month;
        da = day;
        hr = hour;
        mi = min;
        sc = sec;
    }
    //Konstruktor mit Array
    public DateTime(int[] inserts) throws Exception
    {
        if (inserts.length==6) {
            yr = inserts[0];
            mo = inserts[1];
            da = inserts[2];
            hr = inserts[3];
            mi = inserts[4];
            sc = inserts[5];
        } else throw new Exception("Please provide six Integer-Values for creating a DateTime.");
    }
    //Konstruktor mit dem String des Datums und der Zeit aus OpenSenseMap
    public DateTime(String rcf3339date)
    {
        int[] inserts = divideDate(rcf3339date);
        yr = inserts[0];
        mo = inserts[1];
        da = inserts[2];
        hr = inserts[3];
        mi = inserts[4];
        sc = inserts[5];
    }
    
    public String getRCF3339String()
    {
        return makeDate();
    }
    public String getDateTimeFormatted() {
        return "Created on: "+da+". "+mo+". "+yr+" at: "+hr+":"+mi+":"+sc;
    }
    public void modify(int[] inputs) throws Exception
    {
        if (inputs.length==6) {
            yr = yr + inputs[0];
            mo = mo + inputs[1];
            da = da + inputs[2];
            hr = hr + inputs[3];
            mi = mi + inputs[4];
            sc = sc + inputs[5];
            checkValues();
        } else throw new Exception("Please provide six Integer-Values for modifying a DateTime.");
    }
    public int[] getValues()
    {
        int[] ar = {yr,mo,da,hr,mi,sc};
        return ar;
    }
    
    private int[] divideDate(String date) {
        String[] div1 = date.split("T");
        String[] div2 = div1[0].split("-");
        String[] div3 = div1[1].split(":");
        int year = Integer.valueOf(div2[0]);
        int month = Integer.valueOf(div2[1]);
        int day = Integer.valueOf(div2[2]);
        int hour = Integer.valueOf(div3[0]);
        int min = Integer.valueOf(div3[1]);
        int sec = (int) (double) Double.valueOf(div3[2].replace("Z",""));
        int[] ar = {year,month,day,hour,min,sec};
        return ar;
    }
    private String makeDate()
    {
        return addZeroDate(yr)+"-"+addZeroDate(mo)+"-"+addZeroDate(da)+"T"+addZeroDate(hr)+":"+addZeroDate(mi)+":"+addZeroDate(sc)+"Z";
    }
    private String addZeroDate(int input) {
        String out = "";
        if (input<10) out = "0"+input;
        else out = ""+input;
        return out;
    }
    private void checkValues()
    {
        while (sc<0) {
            sc = sc+60;
            mi--;
        } while (sc>=60) {
            sc = sc-60;
            mi++;
        } while (mi<0) {
            mi = mi+60;
            hr--;
        } while (mi>=60) {
            mi = mi-60;
            hr++;
        } while (hr<0) {
            hr = hr+24;
            da--;
        } while (hr>=24) {
            hr = hr-24;
            da++;
        }
    }
}
