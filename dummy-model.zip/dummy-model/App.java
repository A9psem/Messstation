import javafx.application.Application;

public class App extends Application
{
    Model model = new Model();
    
    Controller c = new Controller();
    c.setModel(model);
    c.allesAusgeben();
    
    /* 
           @Override
    public void start() throws Exception
    {
            
      
        //Controller c = loader.getController();
        //c.setModel(model);
       
    }
    public static void main(String[] args) {
            launch(args);
        }
        */
}
