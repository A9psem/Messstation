package weathermodel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.*;
import javafx.scene.layout.VBox;

import weathermodel.assets.*;
import weathermodel.model.*;

public class ModelMain implements Converter {
    
    //Timerobjekt
    private WeatherTimer timer;
    //Koordinaten des Standorts
    private double[] cord;
    //Controller für FXML
    private Controller con;
    //Speicherort für Heruntergeladenes
    public DataStorage storage;
    //DownloadController zum Verwalten der Downloads
    public DownloadController dcon;
    
    private int srt_timer;
    
    private int av_counter;
    
    public ModelMain(double[] coords,double dis,Controller con_) {
        //Initialisieren aller Werte
        con = con_;
        timer = new WeatherTimer(this);
        cord = coords;
        storage = new DataStorage();
        dcon = new DownloadController(this);
        timer.start();
        srt_timer = 0;
        //Generieren der Startdaten
        try {
            //Aktuellen Zeitpunkt erhalten
            Instant instant = Instant.now();
            //Generieren zweier Objekte für Zeit und Datum
            DateTime now = new DateTime(instant.toString());
            DateTime hAgo = new DateTime(instant.toString());
            //Alter Code
            /*
            String[] pars = dtf.format(now).replace(":::","T").split(":");
            int par_int = Integer.valueOf(pars[1]);
            par_int--;
            String par = pars[0]+":"+par_int+":"+pars[2];
            LocalDateTime hAgo = LocalDateTime.parse(par);
            */
            //Modifizieren der DateTimes, um richtigen Zeitpunkt zu erhalten
            int[] ar = {0,0,0,0,0,0};
            now.modify(ar);
            int[] ar1 = {0,0,0,-1,0,0};
            hAgo.modify(ar1);
            //Erhalten der Boxen für das Einfügen der Daten des FXML-Controllers
            VBox[] vboxes = con.getStartBoxes();
            //Erstellen und senden der DataRequests aus den vorher generierten Daten
            DataRequest sr = new DataRequest("LocalTemp","Temperatur",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[0]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalPM2.5","PM2.5",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[1]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalPres","Luftdruck",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[2]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalPM10","PM10",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[3]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalHumd","rel.%20Luftfeuchte",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[4]);
            dcon.makeRequest(sr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void time() {
        //Timer Methode, wird immer wieder ausgeführt
        dcon.update();
        srt_timer++;
        if (srt_timer>=600) {
            av_counter++;
            if (con.getLive()) {
                try {
                    con.liveUpdate();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            srt_timer = 0;
        }
    }
    public void liveRequest(double[] coords,double dis) {
        try {
            //Aktuellen Zeitpunkt erhalten
            Instant instant = Instant.now();
            //Generieren zweier Objekte für Zeit und Datum
            DateTime now = new DateTime(instant.toString());
            DateTime hAgo = new DateTime(instant.toString());
            //Modifizieren der DateTimes, um richtigen Zeitpunkt zu erhalten
            int[] ar = {0,0,0,0,0,0};
            now.modify(ar);
            int[] ar1 = {0,0,0,0,-1,0};
            hAgo.modify(ar1);
            //Erhalten der Boxen für das Einfügen der Daten des FXML-Controllers
            VBox[] vboxes = con.getLiveBoxes();
            //Erstellen und senden der DataRequests aus den vorher generierten Daten
            DataRequest sr = new DataRequest("LiveTemp","Temperatur",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[0]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LivePM2.5","PM2.5",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[1]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LivePres","Luftdruck",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[2]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LivePM10","PM10",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[3]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LiveHumd","rel.%20Luftfeuchte",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[4]);
            dcon.makeRequest(sr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void insertSeries(Series insert) {
        //Fügt eine Serie aus einem Download in den Storage ein und sendet sie an den FXML-Controller weiter
        storage.makeNewElement(insert.getGenerator().getName(),insert);
        con.requestTaken(insert);
    }
    public int getAvCounter() {
        return av_counter;
    }
}
