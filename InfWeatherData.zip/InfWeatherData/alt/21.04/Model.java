import java.util.ArrayList;
public class Model
{
    
    ArrayList<Messwert> messreihetemp;
    ArrayList<Messwert> messreiheluft;

    public Model()
    {
        messreihetemp = new ArrayList<Messwert>();
        messreiheluft = new ArrayList<Messwert>();
    }
    
    
    public void einfuegen(Messwert messwert)
    {
        if(messwert.getArt() == "Temperatur")
        {
            messreihetemp.add(messwert);
        }
        else if(messwert.getArt() == "Luftfeuchtigkeit")
        {
            messreiheluft.add(messwert);
        }
    }
        
    public void allesAusgeben()
    {
        temperaturAusgeben();
        luftfeuchtigkeitAusgeben();
    }
    
    public void temperaturAusgeben()
    {
        System.out.println("Alle Temperaturen:");
        for (int i = 0; i < messreihetemp.size(); i++)
        {
           messreihetemp.get(i).ausgeben();
        }
    }
    
    public void luftfeuchtigkeitAusgeben()
    {
        System.out.println("Alle Luftfeuchtigkeiten:");
        for (int i = 0; i < messreiheluft.size(); i++)
        {
           messreiheluft.get(i).ausgeben();
        }
    }
    
} 
