package weathermodel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.*;
import javafx.scene.layout.VBox;

import weathermodel.assets.*;
import weathermodel.model.*;

public class ModelMain implements Converter {
    
    private WeatherTimer timer;
    private double[] cord;
    private Controller con;
    public DataStorage storage;
    public DownloadController dcon;
    
    public ModelMain(double[] coords,double dis,Controller con_) {
        con = con_;
        timer = new WeatherTimer(this);
        cord = coords;
        storage = new DataStorage();
        dcon = new DownloadController(this);
        timer.start();
        try {
            Instant instant = Instant.now();
            DateTime now = new DateTime(instant.toString());
            DateTime hAgo = new DateTime(instant.toString());
            /*
            String[] pars = dtf.format(now).replace(":::","T").split(":");
            int par_int = Integer.valueOf(pars[1]);
            par_int--;
            String par = pars[0]+":"+par_int+":"+pars[2];
            LocalDateTime hAgo = LocalDateTime.parse(par);
            */
            int[] ar = {0,0,0,0,0,0};
            now.modify(ar);
            int[] ar1 = {0,0,0,-1,0,0};
            hAgo.modify(ar1);
            VBox[] vboxes = con.getStartBoxes();
            DataRequest sr = new DataRequest("LocalTemp","Temperatur",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[0]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalPM2.5","PM2.5",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[1]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalPres","Luftdruck",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[2]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalPM10","PM10",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[3]);
            dcon.makeRequest(sr);
            sr = new DataRequest("LocalHumd","rel.%20Luftfeuchte",makeBBox(cord,dis),hAgo.getRCF3339String(),now.getRCF3339String(),vboxes[4]);
            dcon.makeRequest(sr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void time() {
        
        dcon.update();
    }
    public void insertSeries(Series insert) {
        storage.makeNewElement(insert.getGenerator().getName(),insert);
        con.requestTaken(insert);
    }
}
