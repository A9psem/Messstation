package weathermodel.model;

import java.util.ArrayList;

import weathermodel.assets.DataRequest;
public class Series
{
    private ArrayList<Measurement> list;
    //Ist diese Messreihe valide?
    private boolean isValid;
    //Wurde durch diesen Request erzeugt
    private DataRequest generator;
    //Einige Konstruktoren mit unterschiedlichen Eingaben
    public Series(DataRequest request,ArrayList<Measurement> inlist)
    {
        generator = request;
        list = inlist;
        isValid = true;
    }
    public Series(DataRequest request) {
        generator = request;
        list = new ArrayList<Measurement>();
        isValid = false;
    }
    public Series(DataRequest request,Measurement m)
    {
        generator = request;
        list = new ArrayList<Measurement>();
        isValid = true;
        list.add(m);
    }
    public Series(DataRequest request,Measurement[] array)
    {
        generator = request;
        list = new ArrayList<Measurement>();
        isValid = true;
        for (Measurement m : array) {
            list.add(m);
        }
    }
    
    //Verwaltungsmethoden
    public void addMeasurement(Measurement m) {
        list.add(m);
        isValid = true;
    }
    public void addMeasurements(Measurement[] m) {
        for (Measurement m1 : m) {
            list.add(m1);
        }
        isValid = true;
    }
    public void addMeasurements(ArrayList<Measurement> m) {
        for (Measurement m1 : m) {
            list.add(m1);
        }
        isValid = true;
    }
    
    public void removeMeasurement(Measurement m) {
        list.remove(m);
        checkValid();
    }
    public void removeMeasurements(Measurement[] m) {
        for (Measurement m1 : m) {
            list.remove(m1);
        }
        checkValid();
    }
    public void removeMeasurements(ArrayList<Measurement> m) {
        for (Measurement m1 : m) {
            list.remove(m1);
        }
        checkValid();
    }
    
    public ArrayList<Measurement> getMeasurements() {
        return list;
    }
    public Measurement getMeasurementByID(String id) {
        for (Measurement m : list) {
            if (id.equals(m.getID())) return m;
        }
        return null;
    }
    public Measurement getMeasurementByTimeStamp(String timeStamp) {
        for (Measurement m : list) {
            if (timeStamp.equals(m.getTimeStamp())) return m;
        }
        return null;
    }
    public Measurement getMeasurementByValue(float value) {
        for (Measurement m : list) {
            if (value==m.getValue()) return m;
        }
        return null;
    }
    public ArrayList<Measurement> getMeasurementsByID(String id) {
        ArrayList<Measurement> mlist = new ArrayList<Measurement>();
        for (Measurement m : list) {
            if (id.equals(m.getID())) mlist.add(m);
        }
        return mlist;
    }
    public ArrayList<Measurement> getMeasurementsByTimeStamp(String timeStamp) {
        ArrayList<Measurement> mlist = new ArrayList<Measurement>();
        for (Measurement m : list) {
            if (timeStamp.equals(m.getTimeStamp())) mlist.add(m);
        }
        return mlist;
    }
    public ArrayList<Measurement> getMeasurementsByValue(float value) {
        ArrayList<Measurement> mlist = new ArrayList<Measurement>();
        for (Measurement m : list) {
            if (value==m.getValue()) mlist.add(m);
        }
        return mlist;
    }
    
    public boolean isValid() {
        return isValid;
    }
    private void checkValid() {
        if (list.isEmpty()) isValid = false;
        else isValid = true;
    }
    public String writeToString() {
        String result = "";
        for (Measurement m : list) {
            result = result+m.writeToString()+" ";
        }
        return result;
    }
    public DataRequest getGenerator() {
        return generator;
    }
}

