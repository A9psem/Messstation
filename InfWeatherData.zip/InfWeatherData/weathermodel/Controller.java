package weathermodel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import java.util.ArrayList;
import javafx.scene.text.Font;
import javafx.event.EventHandler;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.NumberAxis;

import java.io.*;

import weathermodel.model.*;
import weathermodel.assets.*;

public class Controller implements Converter {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button buttonStart;

    @FXML
    private ChoiceBox<String[]> choiceBox;

    @FXML
    private CheckBox boxTemp;

    @FXML
    private CheckBox boxHum;

    @FXML
    private CheckBox boxStaub;

    @FXML
    private CheckBox boxPressure;

    @FXML
    private TextField txtLat;

    @FXML
    private TextField txtLon;

    @FXML
    private Slider sliderRadius;

    @FXML
    private CheckBox useCoords;

    @FXML
    private VBox VBoxTemp;

    @FXML
    private VBox VBoxLuft;

    @FXML
    private VBox VBoxFS10;

    @FXML
    private VBox VBoxFS2_5;

    @FXML
    private VBox VBoxDruck;
    
    @FXML
    private VBox setBox;
    
    @FXML
    private TextField searchText;
    
    @FXML
    private CheckBox liveTemp;

    @FXML
    private CheckBox liveStaub;

    @FXML
    private CheckBox livePres;

    @FXML
    private CheckBox liveHumid;

    @FXML
    private VBox liveBoxTemp;

    @FXML
    private VBox liveBoxHumid;

    @FXML
    private VBox liveBoxPM10;

    @FXML
    private VBox liveBoxPM25;

    @FXML
    private VBox liveBoxPres;
    
    @FXML
    private CheckBox liveActive;
    
    @FXML
    private LineChart<Number, Number> liveGraphTemp;
    
    @FXML
    private LineChart<Number, Number> liveGraphPM25;

    @FXML
    private LineChart<Number, Number> liveGraphPres;

    @FXML
    private LineChart<Number, Number> liveGraphPM10;

    @FXML
    private LineChart<Number, Number> liveGraphHumd;
    
    //Hauptklasse
    private ModelMain model;
    //Liste mit allen relevanten Requests, welche erwartet werden, um sie einzufügen
    private ArrayList<String> requests;
    
    private HBox selectedItem;
    
    private ArrayList<String[]> searchTexts;
    
    private double[] coordinates;
    
    private ArrayList<Object[]> average;
    
    private XYChart.Series tempSeries;
    private XYChart.Series pm25Series;
    private XYChart.Series presSeries;
    private XYChart.Series pm10Series;
    private XYChart.Series humdSeries;

    @FXML
    void init(ActionEvent event) {
        try {
            //Mit Knopfdruck werden die Daten aus den Textfeldern übernommen und das Model erstellt
            requests = new ArrayList<String>();
            average = new ArrayList<Object[]>();
            
            tempSeries = new XYChart.Series();
            tempSeries.setName("Temperatur");
            liveGraphTemp.getData().add(tempSeries);
            
            pm25Series = new XYChart.Series();
            pm25Series.setName("PM2.5");
            liveGraphPM25.getData().add(pm25Series);
            
            presSeries = new XYChart.Series();
            presSeries.setName("Luftdruck");
            liveGraphPres.getData().add(presSeries);
            
            pm10Series = new XYChart.Series();
            pm10Series.setName("PM10");
            liveGraphPM10.getData().add(pm10Series);
            
            humdSeries = new XYChart.Series();
            humdSeries.setName("Luftfeuchte");
            liveGraphHumd.getData().add(humdSeries);
            
            boolean bo1 = boxTemp.isSelected();
            boolean bo2 = boxStaub.isSelected();
            boolean bo3 = boxPressure.isSelected();
            boolean bo4 = boxHum.isSelected();
            boolean[] bo = {bo1,bo2,bo3,bo4};
            if (useCoords.isSelected()) {
                double lat = Double.valueOf(txtLat.getText());
                double lon = Double.valueOf(txtLon.getText());
                double[] coords = {lon,lat};
                coordinates = coords;
                if (bo[0]) requests.add("LocalTemp");
                if (bo[1]) requests.add("LocalPM2.5");
                if (bo[2]) requests.add("LocalPres");
                if (bo[1]) requests.add("LocalPM10");
                if (bo[3]) requests.add("LocalHumd");
                double dis = sliderRadius.getValue();
                System.out.println("Distance: "+dis);
                model = new ModelMain(coords,dis,this);
            } else {
                double lat = Double.valueOf(((TextField)selectedItem.getChildren().get(2)).getText().replace(",","."));
                double lon = Double.valueOf(((TextField)selectedItem.getChildren().get(1)).getText().replace(",","."));
                double[] coords = {lon,lat};
                coordinates = coords;
                if (bo[0]) requests.add("LocalTemp");
                if (bo[1]) requests.add("LocalPM2.5");
                if (bo[2]) requests.add("LocalPres");
                if (bo[1]) requests.add("LocalPM10");
                if (bo[3]) requests.add("LocalHumd");
                double dis = sliderRadius.getValue();
                System.out.println("Distance: "+dis);
                model = new ModelMain(coords,dis,this);
            }
            setBox.getChildren().clear();
        } catch (Exception e) {
            System.out.println("Error while initializing the model. Please check your coordinate-inserts.");
            e.printStackTrace();
        }
    }
    
    @FXML
    void searchChanged(ActionEvent event) {
        setBox.getChildren().clear();
        System.out.println(searchText.getText());
        for (String[] strs : searchTexts) {
            try {
                if (strs[0].contains(searchText.getText())) {
                    addToSetBox(strs);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    //Methode, welche nach fertigem Herunterladen von jedem Request zurückgesendet wird
    public void requestTaken(Series insert) {
        String name = insert.getGenerator().getName();
        String res = "";
        //Überpürft, ob die Daten erwartet werden
        for (String s : requests) {
            if (name.equals(s)) res = s;
        }
        //Wenn die Daten gebraucht werden, werden sie eingefügt
        if (!res.equals("")) {
            //Setzen aller Grundwerte
            requests.remove(res);
            DataRequest r = insert.getGenerator();
            VBox box = r.getBox();
            ArrayList<Measurement> in = insert.getMeasurements();
            float av = 0;
            int count = 0;
            for (Measurement m : in) {
                av = av + m.getValue();
                count++;
            }
            av = av/count;
            Object[] objs = {av,r.getToDate()};
            average.add(objs);
            if (r.getPhenomenon().equals("Temperatur")) {
                tempSeries.getData().add(new XYChart.Data(model.getAvCounter(),av));
            }
            if (r.getPhenomenon().equals("PM2.5")) {
                pm25Series.getData().add(new XYChart.Data(model.getAvCounter(),av));
            }
            if (r.getPhenomenon().equals("Luftdruck")) {
                presSeries.getData().add(new XYChart.Data(model.getAvCounter(),av));
            }
            if (r.getPhenomenon().equals("PM10")) {
                pm10Series.getData().add(new XYChart.Data(model.getAvCounter(),av));
            }
            if (r.getPhenomenon().equals("rel.%20Luftfeuchte")) {
                humdSeries.getData().add(new XYChart.Data(model.getAvCounter(),av));
            }
            addAverage(av,r.getPhenomenon(),box);
            count = 0;
            for (Measurement m : in) {
                if (count<5) {
                    addMeasurementToVBox(m,r.getPhenomenon(),box);
                    count++;
                }
            }
            addExtendButton(insert,box);
        } else return;
    }
    //Wird von dem Knopf aufgerufen, der die Daten erweitert
    public void additionalInfo(Series insert) {
        DataRequest r = insert.getGenerator();
        VBox box = r.getBox();
        box.getChildren().clear();
        ArrayList<Measurement> in = insert.getMeasurements();
        float av = 0;
        int count = 0;
        for (Measurement m : in) {
            av = av + m.getValue();
            count++;
        }
        av = av/count;
        addAverage(av,r.getPhenomenon(),box);
        for (Measurement m : in) {
            addMeasurementToVBox(m,r.getPhenomenon(),box);
        }
    }
    
    //Methode zum vereinfachten Weitergeben der VBoxen für den Start
    public VBox[] getStartBoxes() {
        VBox[] ar = {VBoxTemp,VBoxFS2_5,VBoxDruck,VBoxFS10,VBoxLuft};
        return ar;
    }
    public VBox[] getLiveBoxes() {
        VBox[] ar = {liveBoxTemp,liveBoxPM25,liveBoxPres,liveBoxPM10,liveBoxHumid};
        return ar;
    }
    
    //Fügt einen Dateneintrag einer VBox mit dem vorgegeben Layout ein
    private void addMeasurementToVBox(Measurement m,String phenomenon,VBox vbox) {
        float val = m.getValue();
        String rcf = m.getTimeStamp();
        double lat = m.getLat();
        double lon = m.getLon();
        DateTime dt = new DateTime(rcf);
        HBox hbox = new HBox();
        TextField t1 = new TextField(((Float)val).toString()+getUnit(phenomenon));
        TextField t2 = new TextField(dt.getDateTimeFormatted());
        TextField t3 = new TextField("At Location: "+lat+", "+lon);
        t1.setPrefSize(125,25);
        t2.setPrefSize(225,25);
        t3.setPrefSize(250,25);
        t1.setEditable(false);
        t2.setEditable(false);
        t3.setEditable(false);
        hbox.getChildren().add(t1);
        hbox.getChildren().add(t2);
        hbox.getChildren().add(t3);
        vbox.getChildren().add(hbox);
    }
    //Fügt einen Durchschnittswert hinzu
    private void addAverage(float average,String phenomenon,VBox vbox) {
        HBox hbox = new HBox();
        TextField t1 = new TextField("On Average: "+((Float)average).toString()+getUnit(phenomenon));
        t1.setPrefSize(600,40);
        t1.setEditable(false);
        t1.setFont(new Font(24));
        hbox.getChildren().add(t1);
        vbox.getChildren().add(hbox);
    }
    //Fügt einen Erweiterungsknopf hinzu
    private void addExtendButton(Series insert,VBox vbox) {
        StorageButton b = new StorageButton("Show All",insert);
        b.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                additionalInfo((Series)b.getObject());
            }
        });
        vbox.getChildren().add(b);
    }
    
    private void addToSetBox(String[] strs) {
        HBox hbox = new HBox();
        TextField t1 = new TextField(strs[0]);
        TextField t2 = new TextField(strs[1]);
        TextField t3 = new TextField(strs[2]);
        StorageButton b = new StorageButton("X",hbox);
        b.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                selectedItem = (HBox)b.getObject();
            }
        });
        t1.setPrefSize(75,25);
        t2.setPrefSize(38,25);
        t3.setPrefSize(37,25);
        t1.setEditable(false);
        t2.setEditable(false);
        t3.setEditable(false);
        hbox.getChildren().add(t1);
        hbox.getChildren().add(t2);
        hbox.getChildren().add(t3);
        hbox.getChildren().add(b);
        setBox.getChildren().add(hbox);
    }
    
    public void liveUpdate() {
        boolean bo1 = liveTemp.isSelected();
        boolean bo2 = liveStaub.isSelected();
        boolean bo3 = livePres.isSelected();
        boolean bo4 = liveHumid.isSelected();
        boolean[] bo = {bo1,bo2,bo3,bo4};
        double dis = sliderRadius.getValue();
        if (liveTemp.isSelected()) requests.add("LiveTemp");
        if (liveHumid.isSelected()) requests.add("LiveHumd");
        if (liveStaub.isSelected()) requests.add("LivePM2.5");
        if (liveStaub.isSelected()) requests.add("LivePM10");
        if (livePres.isSelected()) requests.add("LivePres");
        model.liveRequest(coordinates,dis);
    }
    
    public void addRequest(String name) {
        requests.add(name);
    }
    public boolean getLive() {
        return liveActive.isSelected();
    }
    
    //Standard-FXML Methode beim Erzeugen
    @FXML
    void initialize() {
        assert buttonStart != null : "fx:id=\"buttonStart\" was not injected: check your FXML file 'view.fxml'.";
        assert txtLat != null : "fx:id=\"txtBreitengrad\" was not injected: check your FXML file 'view.fxml'.";
        assert txtLon != null : "fx:id=\"txtLaengengrad\" was not injected: check your FXML file 'view.fxml'.";
        assert sliderRadius != null : "fx:id=\"sliderRadius\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxFS2_5 != null : "fx:id=\"VBoxFS2_5\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxTemp != null : "fx:id=\"VBoxTemp\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxLuft != null : "fx:id=\"VBoxLuft\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxFS10 != null : "fx:id=\"VBoxFS10\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxDruck != null : "fx:id=\"VBoxDruck\" was not injected: check your FXML file 'view.fxml'.";
        try {
            FileReader fr = new FileReader(new File("libs/Gemeinden.txt"));
            BufferedReader br = new BufferedReader(fr);
            searchTexts = new ArrayList<String[]>();
            String str;
            while ((str = br.readLine()) != null) {
                try {
                    String[] strs = str.split("::");
                    addToSetBox(strs);
                    searchTexts.add(strs);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


