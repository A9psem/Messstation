package weathermodel.assets;

import weathermodel.model.Series;

public class DataElement {
    
    private long id;
    private String name;
    public Series series;
    
    public DataElement(String name_,Series series_,long id_) {
        id = id_;
        name = name_;
        series = series_;
    }
    
    public String getName() {
        return name;
    }
    public long getID() {
        return id;
    }
    public String printString() {
        return name+"("+id+"): "+series.writeToString();
    }
}
