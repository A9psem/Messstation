package weathermodel;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.image.*;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
public class App extends Application
{
    
    public App()
    {
        
    }
    
    //Startmethode
    public void start(Stage stage) throws Exception
    {
        Stage setupStage = new Stage();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view.fxml"));
        Parent root = loader.load();

        // Fenster erstellen und anzeigen
        Scene scene = new Scene(root);
        //scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        setupStage.setScene(scene);
        setupStage.show();
    }
}
