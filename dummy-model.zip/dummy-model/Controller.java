
public class Controller 
{
    private Model model;
    /*
    public Controller(Model model_)
    {
        model = model_;
    }
    */
    public Controller()
    {
    }
        
    public void setModel(Model m)
    {
        model = m;
    }
    public void aktualisieren()
    {
        Messwert messwert1 = new Messwert("10:00", "1.1.10", 1, 1);
        model.einfuegen(messwert1);
    }
    
    public void allesAusgeben()
    {
        model.allesAusgeben();
    }
       
}
