package weathermodel;

import java.util.ArrayList;

import weathermodel.assets.DataElement;
import weathermodel.model.Series;

public class DataStorage {
    //speichert die IDs, sodass keine Doppelungen auftreten
    private long nextID;
    //Liste aller Inhalte
    private ArrayList<DataElement> elist;
    
    //Konstruktor
    public DataStorage() {
        nextID = 1;
        elist = new ArrayList<DataElement>();
    }
    
    //Fügt ein neues Element in den Speicher ein
    public DataElement makeNewElement(String name,Series series) {
        DataElement e = new DataElement(name,series,nextID());
        if (!e.equals(null)) elist.add(e);
        return e;
    }
    //Bearbeitungsmethoden für die Liste
    public DataElement removeElementByName(String name) {
        for (DataElement d : elist) {
            if (name.equals(d.getName())) {
                elist.remove(d);
                return d;
            }
        }
        return null;
    }
    public DataElement removeElementByID(long id) {
        for (DataElement d : elist) {
            if (id==d.getID()) {
                elist.remove(d);
                return d;
            }
        }
        return null;
    }
    
    public DataElement getDataElementByName(String name) {
        for (DataElement d : elist) {
            if (name.equals(d.getName())) return d;
        }
        return null;
    }
    public DataElement getDataElementByID(long id) {
        for (DataElement d : elist) {
            if (id==d.getID()) return d;
        }
        return null;
    }
    public long nextID() {
        nextID++;
        return nextID-1;
    }
}
