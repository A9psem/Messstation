import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button buttonStart;

    @FXML
    private TextField txtBreitengrad;

    @FXML
    private TextField txtLaengengrad;

    @FXML
    private Slider sliderRadius;

    @FXML
    private AnchorPane VBoxFS2_5;

    @FXML
    private VBox VBoxTemp;

    @FXML
    private VBox VBoxLuft;

    @FXML
    private VBox VBoxFS10;

    @FXML
    private VBox VBoxDruck;

    @FXML
    void abrufen(ActionEvent event) {
        String breitengrad = txtBreitengrad.getText();
        String laengengrad = txtLaengengrad.getText();
        System.out.println(breitengrad);
    }
    
    private Model model;
        
    public void setModel(Model m)
    {
        model = m;
    }
    
    public void aktualisieren(Messwert m)
    {
        model.einfuegen(m);
    }
    
    public void allesAusgeben()
    {
        model.allesAusgeben();
    }
    
    public void temperaturAusgeben()
    {
        model.temperaturAusgeben();
    }
    
    public void luftfeuchtigkeitAusgeben()
    {
        model.luftfeuchtigkeitAusgeben();
    }
    
    
    
    @FXML
    void initialize() {
        assert buttonStart != null : "fx:id=\"buttonStart\" was not injected: check your FXML file 'view.fxml'.";
        assert txtBreitengrad != null : "fx:id=\"txtBreitengrad\" was not injected: check your FXML file 'view.fxml'.";
        assert txtLaengengrad != null : "fx:id=\"txtLaengengrad\" was not injected: check your FXML file 'view.fxml'.";
        assert sliderRadius != null : "fx:id=\"sliderRadius\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxFS2_5 != null : "fx:id=\"VBoxFS2_5\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxTemp != null : "fx:id=\"VBoxTemp\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxLuft != null : "fx:id=\"VBoxLuft\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxFS10 != null : "fx:id=\"VBoxFS10\" was not injected: check your FXML file 'view.fxml'.";
        assert VBoxDruck != null : "fx:id=\"VBoxDruck\" was not injected: check your FXML file 'view.fxml'.";

    }
}
