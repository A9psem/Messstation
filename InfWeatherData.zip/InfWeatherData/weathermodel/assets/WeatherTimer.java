package weathermodel.assets;

import javafx.animation.AnimationTimer;
import weathermodel.ModelMain;
public class WeatherTimer extends AnimationTimer
{
    ModelMain main;
    //Standard-AnimationTimer Klasse
    public WeatherTimer(ModelMain main_)
    {
        main = main_;

    }
    private long lastUpdate = 0 ;
    @Override
    public void handle(long now) {
                    if (now - lastUpdate >= 100_000_000) {
                        main.time();
                        lastUpdate = now ;
                    }
            }
}
