package weathermodel.assets;

@Deprecated
public class TripleObject
{
    Object obj1;
    Object obj2;
    Object obj3;
    //Klasse zum zusammenspeichern von drei Objekten
    public TripleObject(Object object1,Object object2,Object object3)
    {
        obj1 = object1;
        obj2 = object2;
        obj3 = object3;
    }
    
    public Object getObj1() {
        return obj1;
    }
    public Object getObj2() {
        return obj2;
    }
    public Object getObj3() {
        return obj3;
    }
    public Object[] getObjs() {
        Object[] res = {obj1,obj2,obj3};
        return res;
    }
}
