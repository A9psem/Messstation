package weathermodel;

import java.util.ArrayList;

import weathermodel.assets.DataRequest;
import weathermodel.model.DownloadData;
import weathermodel.model.Series;

public class DownloadController {
    
    //ArrayList speichert alle Anfragen, bis sie bearbeitet werden können
    private ArrayList<DataRequest> queue;
    //boolean, ob gerade etwas bearbeitet wird
    private boolean canProceed;
    //Der DataRequest, der gerade bearbeitet wird
    private DataRequest currentRequest;
    //Downloader für alle Daten
    private DownloadData loader;
    //Hauptklasse, um Daten dort einzufügen
    private ModelMain main;
    
    //Konstruktor
    public DownloadController(ModelMain model) {
        canProceed = true;
        queue = new ArrayList<DataRequest>();
        loader = new DownloadData();
        main = model;
        //Setzt alle Werte, die benötigt werden
    }
    
    //Methode zum senden eines DataRequests
    public boolean makeRequest(DataRequest r) {
        for (DataRequest qr : queue) {
            if(qr.getStringMod().equals(r.getStringMod())) return false;
        }
        //Überprüft, ob dieser Request sich bereits in der Warteschlange befindet und beendet die Methode, wenn es dort ist
        queue.add(r);
        return true;
        //Fügt den DataRequest in die Warteschlange ein und gibt true zurück
    }
    
    //Methode, die vom Timer aufgerufen wird und einen Download startet, wenn nicht gerade einer läuft
    public void update() {
        if (canProceed&&queue.size()>0) {
            currentRequest = queue.get(0);
            queue.remove(0);
            canProceed = false;
            Series s = loader.getData(currentRequest);
            main.insertSeries(s);
            canProceed = true;
        }
    }
}
