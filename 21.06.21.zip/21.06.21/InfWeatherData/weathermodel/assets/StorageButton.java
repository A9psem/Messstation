package weathermodel.assets;

import javafx.scene.control.Button;

public class StorageButton extends Button
{
    private Object obj;
    
    public StorageButton(Object object)
    {
        super();
        obj = object;
    }
    public StorageButton(String label,Object object)
    {
        super(label);
        obj = object;
    }
    
    public Object getObject() {
        return obj;
    }
    public void setObject(Object object) {
        obj = object;
    }
}
