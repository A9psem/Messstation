package weathermodel;

import java.time.*;

public class Temp {

    public static void main(String[] args) {
        /*File f = new File("libs/kreise.txt");
        File fi = new File("libs/Gemeinden.txt");
        try {
            ArrayList<String> list = new ArrayList<String>();
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            String str;
            while ((str = br.readLine()) != null) {
                str = str.replace("\t", "::");
                str = str.replace(" ", "");
                if (!str.startsWith("50")&&!str.startsWith("40")&&!str.startsWith("30")&&!str.startsWith("20")&&!str.startsWith("10")) {
                    list.add(str);
                }
            }
            br.close();
            FileWriter fw = new FileWriter(fi);
            BufferedWriter bw = new BufferedWriter(fw);
            int i = 0;
            for (String s : list) {
                if (s.contains("\fu")) System.out.println("1 "+s);
                if (s.contains("\tu")) System.out.println("2 "+s);
                if (s.contains("\u2B7Fu")) System.out.println("3 "+s);
                if (i>0) bw.newLine();
                bw.write(s);
                i++;
            }
            bw.close();
        } catch (Exception e) {
            
        }
        
        try {
            Instant instant = Instant.now();
            System.out.println(instant.toString());
            double[] d = {11.434277,48.263583};
            ModelMain mod = new ModelMain(d);
            System.out.println(mod.storage.getDataElementByName("LocalTemp").printString());
        } catch (Exception e) {
            
        }*/
    }
}
