package weathermodel;

import java.util.ArrayList;

import weathermodel.assets.DataElement;
import weathermodel.model.Series;

public class DataStorage {
    
    private long nextID;
    private ArrayList<DataElement> elist;
    
    public DataStorage() {
        nextID = 1;
        elist = new ArrayList<DataElement>();
    }
    
    public DataElement makeNewElement(String name,Series series) {
        DataElement e = new DataElement(name,series,nextID());
        if (!e.equals(null)) elist.add(e);
        return e;
    }
    public DataElement remveElementByName(String name) {
        for (DataElement d : elist) {
            if (name.equals(d.getName())) {
                elist.remove(d);
                return d;
            }
        }
        return null;
    }
    public DataElement remveElementByID(long id) {
        for (DataElement d : elist) {
            if (id==d.getID()) {
                elist.remove(d);
                return d;
            }
        }
        return null;
    }
    
    public DataElement getDataElementByName(String name) {
        for (DataElement d : elist) {
            if (name.equals(d.getName())) return d;
        }
        return null;
    }
    public DataElement getDataElementByID(long id) {
        for (DataElement d : elist) {
            if (id==d.getID()) return d;
        }
        return null;
    }
    public long nextID() {
        nextID++;
        return nextID-1;
    }
}
