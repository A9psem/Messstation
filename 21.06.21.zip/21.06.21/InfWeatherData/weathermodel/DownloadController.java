package weathermodel;

import java.util.ArrayList;

import weathermodel.assets.DataRequest;
import weathermodel.model.DownloadData;
import weathermodel.model.Series;

public class DownloadController {
    
    private ArrayList<DataRequest> queue;
    private boolean canProceed;
    private DataRequest currentRequest;
    private DownloadData loader;
    private ModelMain main;
    
    public DownloadController(ModelMain model) {
        canProceed = true;
        queue = new ArrayList<DataRequest>();
        loader = new DownloadData();
        main = model;
    }
    
    public boolean makeRequest(DataRequest r) {
        for (DataRequest qr : queue) {
            if(qr.getStringMod().equals(r.getStringMod())) return false;
        }
        queue.add(r);
        return true;
    }
    
    public void update() {
        if (canProceed&&queue.size()>0) {
            currentRequest = queue.get(0);
            queue.remove(0);
            canProceed = false;
            Series s = loader.getData(currentRequest);
            main.insertSeries(s);
            canProceed = true;
        }
    }
}
