package weathermodel.assets;

import javafx.scene.layout.VBox;

public class DataRequest {
    
    private String name;
    private String phenomenon;
    private String bbox;
    private String fromDate;
    private String toDate;
    private VBox insertBox;
    private int mode;
    
    public DataRequest(String name_, String phenomenon_, String bbox_, String fromDate_, String toDate_,VBox insertBox_) {
        mode = 1;
        name = name_;
        phenomenon = phenomenon_;
        bbox = bbox_;
        fromDate = fromDate_;
        toDate = toDate_;
        insertBox = insertBox_;
        System.out.println("https://api.opensensemap.org/boxes/data?phenomenon="+phenomenon+"&bbox="+bbox+"&from-date="+fromDate+"&to-date="+toDate+"&format=json");
    }
    
    public String requestFinalString() {
        switch(mode) {
        case 1:
            return "https://api.opensensemap.org/boxes/data?phenomenon="+phenomenon+"&bbox="+bbox+"&from-date="+fromDate+"&to-date="+toDate+"&format=json";
        default:
            return null;
        }
    }
    public String getStringMod() {
        return name+mode+phenomenon+bbox+fromDate+toDate;
    }
    public String getName() {
        return name;
    }
    public VBox getBox() {
        return insertBox;
    }
    public String getPhenomenon() {
        return phenomenon;
    }
}
