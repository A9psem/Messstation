public class Messwert
{
    private String art;
    private int wert;
    private String einheit;
    private String datum;
    private String uhrzeit;
    
    public Messwert(String art_, int wert_, String einheit_, String datum_, String uhrzeit_)
    {
        art = art_;
        wert = wert_;
        einheit = einheit_;
        datum = datum_;
        uhrzeit = uhrzeit_;
    }
    
    public void ausgeben()
    {
        System.out.println("Die " + art + " am " + datum + " um " + uhrzeit +  " beträgt " + wert + " " + einheit);
    }
    
    public String getArt()
    {
        return art;
    }
}
