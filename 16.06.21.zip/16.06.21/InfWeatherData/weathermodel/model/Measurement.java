package weathermodel.model;


public class Measurement
{
    
    private float value;
    private String timeStamp;
    private double lat;
    private double lon;
    private String id;
    
    public Measurement(float value_,String timeStamp_,double lat_,double lon_,String id_)
    {
        value = value_;
        timeStamp = timeStamp_;
        lat = lat_;
        lon = lon_;
        id = id_;
    }
    
    public float getValue() {
        return value;
    }
    public String getTimeStamp() {
        return timeStamp;
    }
    public String getID() {
        return id;
    }
    public double getLat() {
        return lat;
    }
    public double getLon() {
        return lon;
    }
    @Deprecated
    public void setValue(float newValue) {
        value = newValue;
    }
    @Deprecated
    public void overwriteSettings(Measurement m) {
        timeStamp = m.getTimeStamp();
        id = m.getID();
        lat = m.getLat();
        lon = m.getLon();
    }
    
    public boolean matches(String compareID) {
        if (compareID.equals(id)) return true;
        else return false;
    }
    public boolean matches(float compareLat,float compareLon) {
        if (compareLat==lat&&compareLon==lon) return true;
        else return false;
    }
    public String writeToString() {
        return "ID:"+id+",TIME:"+timeStamp+",LAT:"+lat+",LON:"+lon+",VALUE:"+value;
    }
    
}

