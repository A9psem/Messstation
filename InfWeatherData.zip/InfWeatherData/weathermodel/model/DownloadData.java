package weathermodel.model;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.net.URL;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import weathermodel.assets.DataRequest;
public class DownloadData {
    
    public DownloadData() {
        
    }
    
    //Downloads Data from OpenSenseMap with the given parameters. Downloads it to StreamFile.json, reads it out and convert it to a Series and returns it.
    @SuppressWarnings("unchecked")
    public Series getData(DataRequest request) {
        try {
            URL downloadurl = new URL(request.requestFinalString());
            File downloadingFile = new File("StreamFile.json");
            if (downloadingFile.exists()==false) downloadingFile.createNewFile();
            BufferedInputStream in = new BufferedInputStream(downloadurl.openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(downloadingFile);
            byte dataBuffer[] = new byte[1048576];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, 1048576)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
            }
            fileOutputStream.close();
            
            Series s = new Series(request);
            JSONParser jsonParser = new JSONParser();
            FileReader fr = new FileReader(downloadingFile);
            Object obj = jsonParser.parse(fr);
            JSONArray jsonMes = (JSONArray) obj;
            jsonMes.forEach(mes -> serializeMeasurement((JSONObject) mes,s));
            return s;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    private void serializeMeasurement(JSONObject obj,Series s) {
        String timeStamp = (String) obj.get("createdAt");
        float value = Float.valueOf((String)obj.get("value"));
        String id = (String) obj.get("sensorId");
        double lat = (Double) obj.get("lat");
        double lon = (Double) obj.get("lon");
        Measurement m = new Measurement(value,timeStamp,lat,lon,id);
        s.addMeasurement(m);
    }
    
    //Download Data from OpenSenseMap with the given parameters. Downloads this to DownloadFile.json. Returns true when completed.
    public boolean downloadData(String phenomenon,String bbox,String timeBegin,String timeEnd) {
        try {
            URL downloadurl = new URL("https://api.opensensemap.org/boxes/data?phenomenon="+phenomenon+"&bbox="+bbox+"&from-date="+timeBegin+"&to-date="+timeEnd+"&format=json");
            File downloadingFile = new File("DownloadFile.json");
            if (downloadingFile.exists()==false) downloadingFile.createNewFile();
            BufferedInputStream in = new BufferedInputStream(downloadurl.openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(downloadingFile);
            byte dataBuffer[] = new byte[1024];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
            }
            fileOutputStream.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    //Download Data from OpenSenseMap with the given parameters. Use FilePath and end it with FileName, .json is attached. Returns true when completed.
    public boolean downloadData(String phenomenon,String bbox,String timeBegin,String timeEnd,String filePath) {
        try {
            URL downloadurl = new URL("https://api.opensensemap.org/boxes/data?phenomenon="+phenomenon+"&bbox="+bbox+"&from-date="+timeBegin+"&to-date="+timeEnd+"&format=json");
            File downloadingFile = new File(filePath+".json");
            if (downloadingFile.exists()==false) downloadingFile.createNewFile();
            BufferedInputStream in = new BufferedInputStream(downloadurl.openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(downloadingFile);
            byte dataBuffer[] = new byte[1024];
            int bytesRead;
            while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
                fileOutputStream.write(dataBuffer, 0, bytesRead);
            }
            fileOutputStream.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
